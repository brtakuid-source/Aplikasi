# SMS Forwarder

## Cara dapat APK
**Opsi A - GitHub (tanpa install apa pun):**
1. Buat repo baru di GitHub, upload semua isi folder ini (termasuk folder `.github`).
2. Buka tab **Actions** -> workflow **Build APK** -> tunggu selesai (~3-5 menit).
3. Unduh artifact **SmsForwarder-apk** -> ekstrak -> `app-debug.apk`.

**Opsi B - Android Studio:** File > Open folder ini, tunggu sync, lalu Build > Build APK(s).

## Pemasangan
Izinkan "install dari sumber tidak dikenal", pasang APK, buka app, isi URL webhook, tekan Simpan lalu izinkan akses SMS, lalu Kirim tes.
