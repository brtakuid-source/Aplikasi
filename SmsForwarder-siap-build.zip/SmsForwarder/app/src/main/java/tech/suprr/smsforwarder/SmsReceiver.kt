package tech.suprr.smsforwarder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Forwarder {
    const val DEFAULT_URL = "https://suprr.tech/sms?key=smssaya"

    fun post(url: String, from: String, message: String): Boolean {
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 15000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            val body = JSONObject().put("from", from).put("message", message).toString()
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val ok = c.responseCode in 200..299
            c.disconnect()
            ok
        } catch (e: Exception) {
            false
        }
    }
}

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val prefs = context.getSharedPreferences("cfg", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("on", true)) return
        val url = prefs.getString("url", Forwarder.DEFAULT_URL) ?: return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        if (msgs.isEmpty()) return
        val from = msgs.first().originatingAddress ?: "?"
        val body = msgs.joinToString("") { it.messageBody ?: "" }
        val pending = goAsync()
        Thread {
            try { Forwarder.post(url, from, body) } finally { pending.finish() }
        }.start()
    }
}
