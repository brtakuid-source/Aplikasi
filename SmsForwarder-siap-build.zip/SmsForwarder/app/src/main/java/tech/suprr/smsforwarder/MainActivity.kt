package tech.suprr.smsforwarder

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        val title = TextView(this).apply { text = "SMS Forwarder"; textSize = 22f }
        val info = TextView(this).apply {
            text = "Meneruskan SMS yang masuk ke HP ini ke URL webhook Anda sendiri."
        }
        val url = EditText(this).apply {
            setText(prefs.getString("url", Forwarder.DEFAULT_URL))
            hint = "URL webhook"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        }
        val sw = Switch(this).apply {
            text = "Teruskan SMS masuk"
            isChecked = prefs.getBoolean("on", true)
        }
        val status = TextView(this)
        val save = Button(this).apply { text = "Simpan" }
        val test = Button(this).apply { text = "Kirim tes" }

        save.setOnClickListener {
            prefs.edit()
                .putString("url", url.text.toString().trim())
                .putBoolean("on", sw.isChecked)
                .apply()
            status.text = "Tersimpan"
            ensurePermission()
        }
        test.setOnClickListener {
            val u = url.text.toString().trim()
            status.text = "Mengirim..."
            Thread {
                val ok = Forwarder.post(u, "TEST", "Tes dari app SMS Forwarder")
                runOnUiThread { status.text = if (ok) "Tes terkirim ✅" else "Tes gagal ❌" }
            }.start()
        }

        listOf(title, info, url, sw, save, test, status).forEach { root.addView(it) }
        setContentView(root)
        ensurePermission()
    }

    private fun ensurePermission() {
        if (checkSelfPermission(Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECEIVE_SMS), 1)
        }
    }
}
